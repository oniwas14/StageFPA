<?php

require 'Forme.php';
class Triangle implements Forme
{
    private $hauteur;
    private $base;

    public function __construct($base,$hauteur)
    {
        $this->base=$base;
        $this->hauteur=$hauteur;
    }

    public function calculerSurface()
    {
        $resultat = ($this->base*$this->hauteur)/2;
        return $resultat;
    }
}

$triangle = new Triangle(2,10);
echo $triangle->calculerSurface();