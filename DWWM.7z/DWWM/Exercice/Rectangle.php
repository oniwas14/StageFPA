<?php

require 'Forme.php';
class Rectangle implements Forme
{
    private $longueur;
    private $largeur;

    public function __construct($largeur,$longueur)
    {
        $this->largeur=$largeur;
        $this->longueur=$longueur;
    }

    public function calculerSurface()
    {
        return $this->longueur*$this->largeur;
    }
}

$rectangle = new Rectangle(10,2);
echo "la surface vaut : ".$rectangle->calculerSurface();