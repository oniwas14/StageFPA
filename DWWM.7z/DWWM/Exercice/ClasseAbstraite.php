<?php

abstract class ClasseAbstraite
{
    private $value=42;

    abstract public function affiche();

    public function getValue(){
        return $this->value;
    }
}

class Test extends ClasseAbstraite{
    public function affiche()
    {
        echo $this->getValue();
    }
}

$test = new Test();
$test->affiche();