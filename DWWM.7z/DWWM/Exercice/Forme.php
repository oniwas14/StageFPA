<?php

interface Forme
{
    public function calculerSurface();

}

