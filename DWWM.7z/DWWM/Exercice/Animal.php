<?php

class Animal
{
    protected $nom;

    public function donneUnBiscuit(){
        echo "Chope le biscuit ";
    }
}
