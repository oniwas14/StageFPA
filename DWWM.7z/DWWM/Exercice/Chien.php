<?php
require 'Animal.php';
class Chien extends Animal
{

}

$chien = new Chien();
$chien->donneUnBiscuit();