<?php

class Personne
{
    private $nom;
    private $prenom;
    private $age;

    static public $taille= 180;

    /**
     * @param $nom
     * @param $prénom
     * @param $age
     */
    public function __construct($nom, $prenom, $age)
    {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->age = $age;
    }

    public function __destruct(){
        echo "objet detruit\n";
    }
    /**
     * @return mixed
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * @param mixed $nom
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    }

    /**
     * @return mixed
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * @param mixed $prénom
     */
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;
    }

    /**
     * @return mixed
     */
    public function getAge()
    {
        return $this->age;
    }

    /**
     * @param mixed $age
     */
    public function setAge($age)
    {
        if ($age <= 0 ){
            throw new Exception("L'age ne peut pas etre inferieur a zéro");
        }
        $this->age = $age;
    }

    public function __toString()
    {
        // TODO: Implement __toString() method.
        return "Je m'appelle ".$this->getNom()." ".$this->getPrenom()." et j'ai ".$this->getAge()." ans.\n";
    }


}

$person = new Personne("Dupont", "Alain", 42 );
echo $person->__toString();
$person->setAge(1);

echo Personne::$taille."\n";